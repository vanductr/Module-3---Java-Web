create
    definer = root@localhost procedure UpdateProduct(IN p_productId int, IN p_productCode varchar(255),
                                                     IN p_productName varchar(255), IN p_productPrice decimal(10, 2),
                                                     IN p_productAmount int, IN p_productDescription varchar(255),
                                                     IN p_productStatus int)
BEGIN
    UPDATE Products
    SET
        productCode = p_productCode,
        productName = p_productName,
        productPrice = p_productPrice,
        productAmount = p_productAmount,
        productDescription = p_productDescription,
        productStatus = p_productStatus
    WHERE
        id = p_productId;
END;

