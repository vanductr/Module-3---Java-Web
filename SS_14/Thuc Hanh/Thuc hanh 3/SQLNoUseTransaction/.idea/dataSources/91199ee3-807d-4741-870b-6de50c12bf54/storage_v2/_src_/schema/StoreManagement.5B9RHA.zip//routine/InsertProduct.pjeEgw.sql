create
    definer = root@localhost procedure InsertProduct(IN p_productCode varchar(255), IN p_productName varchar(255),
                                                     IN p_productPrice decimal(10, 2), IN p_productAmount int,
                                                     IN p_productDescription varchar(255), IN p_productStatus int)
BEGIN
    INSERT INTO Products (
        productCode,
        productName,
        productPrice,
        productAmount,
        productDescription,
        productStatus
    ) VALUES (
        p_productCode,
        p_productName,
        p_productPrice,
        p_productAmount,
        p_productDescription,
        p_productStatus
    );
END;

