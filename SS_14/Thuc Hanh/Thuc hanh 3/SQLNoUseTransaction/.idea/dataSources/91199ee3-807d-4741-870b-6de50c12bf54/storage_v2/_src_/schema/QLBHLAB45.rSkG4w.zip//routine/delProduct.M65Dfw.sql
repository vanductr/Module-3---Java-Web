create
    definer = root@localhost procedure delProduct(IN productName varchar(255))
BEGIN
    DECLARE productID INT;
    
    -- Lấy productID của sản phẩm cần xóa
    SELECT pID INTO productID FROM Product WHERE pName = productName;
    
    -- Xóa các bản ghi liên quan trong bảng OrderDetail
    DELETE FROM OrderDetail WHERE pID = productID;
    
    -- Xóa sản phẩm từ bảng Product
    DELETE FROM Product WHERE pName = productName;
    
    SELECT CONCAT('Product ', productName, ' has been deleted along with its details in OrderDetail.') AS Message;
END;

