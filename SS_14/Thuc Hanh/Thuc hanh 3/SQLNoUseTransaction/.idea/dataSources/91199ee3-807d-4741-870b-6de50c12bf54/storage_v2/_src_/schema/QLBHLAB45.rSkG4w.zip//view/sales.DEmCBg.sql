create definer = root@localhost view sales as
select sum((`od`.`odQTY` * `p`.`pPrice`)) AS `Sales`
from (`qlbhlab45`.`orderdetail` `od` join `qlbhlab45`.`product` `p` on ((`od`.`pID` = `p`.`pID`)));

