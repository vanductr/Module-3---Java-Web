create
    definer = root@localhost procedure get_user_by_id(IN user_id int)
BEGIN
    SELECT users.name, users.email, users.country
    FROM users
    where users.id = user_id;
    END;

