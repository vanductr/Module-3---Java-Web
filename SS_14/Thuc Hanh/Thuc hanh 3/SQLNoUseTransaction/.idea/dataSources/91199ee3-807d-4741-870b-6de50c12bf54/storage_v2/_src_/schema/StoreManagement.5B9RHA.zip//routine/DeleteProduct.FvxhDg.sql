create
    definer = root@localhost procedure DeleteProduct(IN p_productId int)
BEGIN
    DELETE FROM Products WHERE id = p_productId;
END;

