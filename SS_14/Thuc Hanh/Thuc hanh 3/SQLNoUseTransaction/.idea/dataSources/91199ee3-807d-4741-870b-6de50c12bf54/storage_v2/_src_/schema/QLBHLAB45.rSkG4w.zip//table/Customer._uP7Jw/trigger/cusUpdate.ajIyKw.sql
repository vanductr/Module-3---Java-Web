create definer = root@localhost trigger cusUpdate
    after update
    on Customer
    for each row
BEGIN
    UPDATE Orders
    SET cID = NEW.cID
    WHERE cID = OLD.cID;
END;

