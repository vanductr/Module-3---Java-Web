create definer = root@localhost view tblrank as
select row_number() OVER (ORDER BY `ticketfile`.`tblphim`.`Ten_phim` ) AS `STT`,
       `ticketfile`.`tblphim`.`Ten_phim`                               AS `TenPhim`,
       `ticketfile`.`tblphim`.`Thoi_gian`                              AS `Thoi_gian`
from `ticketfile`.`tblphim`;

