create
    definer = root@localhost procedure UpdateTrangThaiPhong()
BEGIN
    -- Cập nhật giá trị của cột Trang_thai theo các luật đã cho
    UPDATE tblPhong
    SET Trang_thai = CASE 
                        WHEN Trang_thai = 0 THEN 'Đang sửa'
                        WHEN Trang_thai = 1 THEN 'Đang sử dụng'
                        ELSE 'Unknown'
                    END;

    -- Hiển thị bảng tblPhong sau khi cập nhật
    SELECT * FROM tblPhong;
END;

